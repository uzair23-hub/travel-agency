using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using TravelAgency.Models;

namespace TravelAgency.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Tour> Tours { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<ContactMessage> ContactMessages { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Tour>().HasData(
                new Tour
                {
                    Id = 1,
                    Title = "Maldives Paradise Escape",
                    Destination = "Maldives",
                    Price = 2499,
                    Description = "Experience crystal-clear waters, pristine white sandy beaches, and luxurious overwater bungalows in the heart of the Indian Ocean. This all-inclusive escape includes snorkeling, diving, and sunset cruises.",
                    ImageUrl = "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=800&q=80",
                    Duration = "7 Days / 6 Nights",
                    Category = "Beach",
                    MaxGroupSize = 12,
                    Rating = 4.9,
                    IsFeatured = true
                },
                new Tour
                {
                    Id = 2,
                    Title = "Swiss Alps Adventure",
                    Destination = "Switzerland",
                    Price = 3299,
                    Description = "Trek through breathtaking alpine landscapes, visit charming villages, and experience world-class skiing in the Swiss Alps. Includes cable car rides and fondue evenings.",
                    ImageUrl = "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=800&q=80",
                    Duration = "8 Days / 7 Nights",
                    Category = "Adventure",
                    MaxGroupSize = 10,
                    Rating = 4.8,
                    IsFeatured = true
                },
                new Tour
                {
                    Id = 3,
                    Title = "Bali Cultural Journey",
                    Destination = "Bali, Indonesia",
                    Price = 1799,
                    Description = "Immerse yourself in Bali's rich spiritual culture, visit ancient temples, lush rice terraces, and experience traditional Balinese ceremonies and cuisine.",
                    ImageUrl = "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800&q=80",
                    Duration = "6 Days / 5 Nights",
                    Category = "Culture",
                    MaxGroupSize = 15,
                    Rating = 4.7,
                    IsFeatured = true
                },
                new Tour
                {
                    Id = 4,
                    Title = "Santorini Sunset Cruise",
                    Destination = "Santorini, Greece",
                    Price = 2199,
                    Description = "Discover the magic of Santorini's iconic blue-domed churches, volcanic beaches, and world-famous sunsets. Enjoy a luxury catamaran cruise and fine Greek dining.",
                    ImageUrl = "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800&q=80",
                    Duration = "5 Days / 4 Nights",
                    Category = "Luxury",
                    MaxGroupSize = 10,
                    Rating = 4.9,
                    IsFeatured = false
                },
                new Tour
                {
                    Id = 5,
                    Title = "Safari in Kenya",
                    Destination = "Kenya, Africa",
                    Price = 4199,
                    Description = "Witness the Great Migration in the Masai Mara, encounter the Big Five, and experience authentic bush camps under a sky full of stars. A life-changing African adventure.",
                    ImageUrl = "https://images.unsplash.com/photo-1516026672322-bc52d61a55d5?w=800&q=80",
                    Duration = "9 Days / 8 Nights",
                    Category = "Adventure",
                    MaxGroupSize = 8,
                    Rating = 4.8,
                    IsFeatured = true
                },
                new Tour
                {
                    Id = 6,
                    Title = "Tokyo Tech & Tradition",
                    Destination = "Tokyo, Japan",
                    Price = 2899,
                    Description = "Experience the perfect blend of ultra-modern technology and centuries-old tradition. Explore neon-lit Shibuya, serene Shinto shrines, bullet trains, and authentic ramen culture.",
                    ImageUrl = "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&q=80",
                    Duration = "7 Days / 6 Nights",
                    Category = "Culture",
                    MaxGroupSize = 14,
                    Rating = 4.7,
                    IsFeatured = false
                }
            );
        }
    }
}
