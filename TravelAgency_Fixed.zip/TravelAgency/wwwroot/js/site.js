// =============================================
// VOYAGER TRAVEL AGENCY — SITE.JS
// =============================================

document.addEventListener('DOMContentLoaded', function () {

  // ---- Navbar scroll behaviour ----
  const nav = document.getElementById('mainNav');
  if (nav) {
    const updateNav = () => {
      nav.classList.toggle('scrolled', window.scrollY > 60);
    };
    window.addEventListener('scroll', updateNav, { passive: true });
    updateNav();
  }

  // ---- Hero background lazy-load ----
  const heroBg = document.querySelector('.hero-bg');
  if (heroBg) {
    setTimeout(() => heroBg.classList.add('loaded'), 100);
  }

  // ---- Auto-dismiss toast ----
  const toast = document.getElementById('successToast');
  if (toast) {
    setTimeout(() => toast.remove(), 4200);
  }

  // ---- Tour card image fallback ----
  document.querySelectorAll('.tour-card-img img, .booking-summary-img, .tour-detail-img img').forEach(img => {
    img.addEventListener('error', () => {
      img.src = 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=600&q=80';
    });
  });

  // ---- Booking: live total price calc ----
  const travelerSelect = document.querySelector('[name="NumberOfTravelers"]');
  const priceDisplay = document.querySelector('.sidebar-price');

  if (travelerSelect && priceDisplay) {
    const baseText = priceDisplay.textContent;
    const basePrice = parseInt(baseText.replace(/[^0-9]/g, ''), 10);

    if (!isNaN(basePrice)) {
      travelerSelect.addEventListener('change', () => {
        const count = parseInt(travelerSelect.value, 10);
        const total = basePrice * count;
        priceDisplay.textContent = '$' + total.toLocaleString();
      });
    }
  }

  // ---- Admin image URL preview ----
  const imageUrlInput = document.querySelector('[name="ImageUrl"]');
  if (imageUrlInput) {
    let previewEl = document.querySelector('.admin-img-preview');

    imageUrlInput.addEventListener('input', debounce(() => {
      const url = imageUrlInput.value.trim();
      if (!url) { if (previewEl) previewEl.style.opacity = '0'; return; }

      if (!previewEl) {
        previewEl = document.createElement('img');
        previewEl.className = 'img-thumbnail mt-2 admin-img-preview';
        previewEl.style.maxHeight = '120px';
        previewEl.style.transition = 'opacity 0.3s ease';
        imageUrlInput.parentNode.appendChild(previewEl);
      }
      previewEl.src = url;
      previewEl.style.opacity = '1';
      previewEl.onerror = () => { previewEl.style.opacity = '0'; };
    }, 600));
  }

  // ---- Smooth scroll for anchor links ----
  document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
      const target = document.querySelector(a.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // ---- Animate elements on scroll ----
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });

    document.querySelectorAll('.tour-card, .stat-card, .testimonial-card, .value-card').forEach(el => {
      el.classList.add('animate-ready');
      observer.observe(el);
    });
  }

  // ---- Min date guard for travel date input ----
  const dateInput = document.querySelector('input[type="date"][name="TravelDate"]');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.setAttribute('min', today);
  }

});

// ---- Utility: debounce ----
function debounce(fn, delay) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}
