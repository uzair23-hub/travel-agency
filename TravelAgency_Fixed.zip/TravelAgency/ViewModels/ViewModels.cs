using System.ComponentModel.DataAnnotations;
using TravelAgency.Models;

namespace TravelAgency.ViewModels
{
    // Home Page
    public class HomeViewModel
    {
        public List<Tour> FeaturedTours { get; set; } = new();
        public int TotalTours { get; set; }
        public int TotalDestinations { get; set; }
        public int HappyTravelers { get; set; }
    }

    // Tours List
    public class ToursViewModel
    {
        public List<Tour> Tours { get; set; } = new();
        public string? SearchDestination { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public string? Category { get; set; }
        public List<string> Categories { get; set; } = new();
    }

    // Booking
    public class BookingViewModel
    {
        public Tour? Tour { get; set; }

        [Required(ErrorMessage = "Your name is required")]
        [MaxLength(100)]
        [Display(Name = "Full Name")]
        public string UserName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email address is required")]
        [EmailAddress]
        [Display(Name = "Email Address")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Phone number is required")]
        [Phone]
        [Display(Name = "Phone Number")]
        public string Phone { get; set; } = string.Empty;

        [Required(ErrorMessage = "Travel date is required")]
        [Display(Name = "Travel Date")]
        [DataType(DataType.Date)]
        public DateTime TravelDate { get; set; } = DateTime.Today.AddDays(30);

        [Range(1, 20, ErrorMessage = "Number of travelers must be between 1 and 20")]
        [Display(Name = "Number of Travelers")]
        public int NumberOfTravelers { get; set; } = 1;

        [Display(Name = "Special Requests")]
        public string? SpecialRequests { get; set; }

        public int TourId { get; set; }
    }

    // Register
    public class RegisterViewModel
    {
        [Required]
        [Display(Name = "Full Name")]
        [MaxLength(100)]
        public string FullName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [Display(Name = "Email Address")]
        public string Email { get; set; } = string.Empty;

        [Required]
        [StringLength(100, MinimumLength = 6)]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        [DataType(DataType.Password)]
        [Display(Name = "Confirm Password")]
        [Compare("Password", ErrorMessage = "Passwords do not match.")]
        public string ConfirmPassword { get; set; } = string.Empty;
    }

    // Login
    public class LoginViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        [Display(Name = "Remember me")]
        public bool RememberMe { get; set; }
    }

    // Contact
    public class ContactViewModel
    {
        [Required(ErrorMessage = "Name is required")]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [MaxLength(200)]
        public string? Subject { get; set; }

        [Required(ErrorMessage = "Message is required")]
        public string Message { get; set; } = string.Empty;
    }

    // Admin Tour Form
    public class TourFormViewModel
    {
        public int Id { get; set; }

        [Required, MaxLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required, MaxLength(200)]
        public string Destination { get; set; } = string.Empty;

        [Required]
        [Range(1, 100000)]
        public decimal Price { get; set; }

        [Required]
        public string Description { get; set; } = string.Empty;

        public string? ImageUrl { get; set; }

        [MaxLength(100)]
        public string? Duration { get; set; }

        [MaxLength(100)]
        public string? Category { get; set; }

        public int? MaxGroupSize { get; set; }

        public bool IsFeatured { get; set; }
        public bool IsActive { get; set; } = true;
    }

    // Admin Dashboard
    public class AdminDashboardViewModel
    {
        public int TotalTours { get; set; }
        public int TotalBookings { get; set; }
        public int PendingBookings { get; set; }
        public int TotalMessages { get; set; }
        public decimal TotalRevenue { get; set; }
        public List<Booking> RecentBookings { get; set; } = new();
    }
}
