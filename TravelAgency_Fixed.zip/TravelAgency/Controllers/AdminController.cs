using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TravelAgency.Data;
using TravelAgency.Models;
using TravelAgency.ViewModels;

namespace TravelAgency.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Dashboard
        public async Task<IActionResult> Index()
        {
            var bookings = await _context.Bookings.Include(b => b.Tour).OrderByDescending(b => b.BookedAt).Take(5).ToListAsync();
            var vm = new AdminDashboardViewModel
            {
                TotalTours = await _context.Tours.CountAsync(),
                TotalBookings = await _context.Bookings.CountAsync(),
                PendingBookings = await _context.Bookings.CountAsync(b => b.Status == BookingStatus.Pending),
                TotalMessages = await _context.ContactMessages.CountAsync(m => !m.IsRead),
                TotalRevenue = await _context.Bookings
                    .Where(b => b.Status == BookingStatus.Confirmed || b.Status == BookingStatus.Completed)
                    .Include(b => b.Tour)
                    .SumAsync(b => b.Tour != null ? b.Tour.Price * b.NumberOfTravelers : 0),
                RecentBookings = bookings
            };
            return View(vm);
        }

        // Tours
        public async Task<IActionResult> Tours()
        {
            var tours = await _context.Tours.OrderByDescending(t => t.CreatedAt).ToListAsync();
            return View(tours);
        }

        public IActionResult CreateTour() => View(new TourFormViewModel { IsActive = true });

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateTour(TourFormViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var tour = new Tour
            {
                Title = vm.Title,
                Destination = vm.Destination,
                Price = vm.Price,
                Description = vm.Description,
                ImageUrl = vm.ImageUrl,
                Duration = vm.Duration,
                Category = vm.Category,
                MaxGroupSize = vm.MaxGroupSize,
                IsFeatured = vm.IsFeatured,
                IsActive = vm.IsActive
            };
            _context.Tours.Add(tour);
            await _context.SaveChangesAsync();
            TempData["Success"] = "Tour created successfully!";
            return RedirectToAction(nameof(Tours));
        }

        public async Task<IActionResult> EditTour(int id)
        {
            var tour = await _context.Tours.FindAsync(id);
            if (tour == null) return NotFound();

            var vm = new TourFormViewModel
            {
                Id = tour.Id,
                Title = tour.Title,
                Destination = tour.Destination,
                Price = tour.Price,
                Description = tour.Description,
                ImageUrl = tour.ImageUrl,
                Duration = tour.Duration,
                Category = tour.Category,
                MaxGroupSize = tour.MaxGroupSize,
                IsFeatured = tour.IsFeatured,
                IsActive = tour.IsActive
            };
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditTour(TourFormViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var tour = await _context.Tours.FindAsync(vm.Id);
            if (tour == null) return NotFound();

            tour.Title = vm.Title;
            tour.Destination = vm.Destination;
            tour.Price = vm.Price;
            tour.Description = vm.Description;
            tour.ImageUrl = vm.ImageUrl;
            tour.Duration = vm.Duration;
            tour.Category = vm.Category;
            tour.MaxGroupSize = vm.MaxGroupSize;
            tour.IsFeatured = vm.IsFeatured;
            tour.IsActive = vm.IsActive;

            await _context.SaveChangesAsync();
            TempData["Success"] = "Tour updated successfully!";
            return RedirectToAction(nameof(Tours));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteTour(int id)
        {
            var tour = await _context.Tours.FindAsync(id);
            if (tour != null)
            {
                _context.Tours.Remove(tour);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Tour deleted successfully!";
            }
            return RedirectToAction(nameof(Tours));
        }

        // Bookings
        public async Task<IActionResult> Bookings()
        {
            var bookings = await _context.Bookings
                .Include(b => b.Tour)
                .OrderByDescending(b => b.BookedAt)
                .ToListAsync();
            return View(bookings);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateBookingStatus(int id, BookingStatus status)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking != null)
            {
                booking.Status = status;
                await _context.SaveChangesAsync();
                TempData["Success"] = "Booking status updated!";
            }
            return RedirectToAction(nameof(Bookings));
        }

        // Messages
        public async Task<IActionResult> Messages()
        {
            var messages = await _context.ContactMessages
                .OrderByDescending(m => m.SentAt)
                .ToListAsync();
            return View(messages);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkMessageRead(int id)
        {
            var msg = await _context.ContactMessages.FindAsync(id);
            if (msg != null) { msg.IsRead = true; await _context.SaveChangesAsync(); }
            return RedirectToAction(nameof(Messages));
        }
    }
}
