using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TravelAgency.Data;
using TravelAgency.Models;
using TravelAgency.ViewModels;

namespace TravelAgency.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var featured = await _context.Tours
                .Where(t => t.IsFeatured && t.IsActive)
                .Take(4)
                .ToListAsync();

            var vm = new HomeViewModel
            {
                FeaturedTours = featured,
                TotalTours = await _context.Tours.CountAsync(t => t.IsActive),
                TotalDestinations = await _context.Tours.Select(t => t.Destination).Distinct().CountAsync(),
                HappyTravelers = 15000
            };

            return View(vm);
        }

        public IActionResult About() => View();

        public IActionResult Contact() => View(new ContactViewModel());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Contact(ContactViewModel vm)
        {
            if (!ModelState.IsValid) return View(vm);

            var msg = new ContactMessage
            {
                Name = vm.Name,
                Email = vm.Email,
                Subject = vm.Subject,
                Message = vm.Message
            };
            _context.ContactMessages.Add(msg);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Thank you! Your message has been sent successfully.";
            return RedirectToAction(nameof(Contact));
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View();
        }
    }
}
