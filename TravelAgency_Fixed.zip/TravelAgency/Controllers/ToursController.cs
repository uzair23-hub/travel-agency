using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TravelAgency.Data;
using TravelAgency.ViewModels;

namespace TravelAgency.Controllers
{
    public class ToursController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ToursController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string? search, decimal? minPrice, decimal? maxPrice, string? category)
        {
            var query = _context.Tours.Where(t => t.IsActive).AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
                query = query.Where(t => t.Destination.Contains(search) || t.Title.Contains(search));

            if (minPrice.HasValue)
                query = query.Where(t => t.Price >= minPrice.Value);

            if (maxPrice.HasValue)
                query = query.Where(t => t.Price <= maxPrice.Value);

            if (!string.IsNullOrWhiteSpace(category))
                query = query.Where(t => t.Category == category);

            var categories = await _context.Tours
                .Where(t => t.IsActive && t.Category != null)
                .Select(t => t.Category!)
                .Distinct()
                .ToListAsync();

            var vm = new ToursViewModel
            {
                Tours = await query.OrderByDescending(t => t.Rating).ToListAsync(),
                SearchDestination = search,
                MinPrice = minPrice,
                MaxPrice = maxPrice,
                Category = category,
                Categories = categories
            };

            return View(vm);
        }

        public async Task<IActionResult> Details(int id)
        {
            var tour = await _context.Tours.FirstOrDefaultAsync(t => t.Id == id && t.IsActive);
            if (tour == null) return NotFound();

            ViewBag.RelatedTours = await _context.Tours
                .Where(t => t.Id != id && t.IsActive && t.Category == tour.Category)
                .Take(3)
                .ToListAsync();

            return View(tour);
        }
    }
}
