using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TravelAgency.Data;
using TravelAgency.Models;
using TravelAgency.ViewModels;

namespace TravelAgency.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Create(int tourId)
        {
            var tour = await _context.Tours.FindAsync(tourId);
            if (tour == null) return NotFound();

            var vm = new BookingViewModel
            {
                TourId = tourId,
                Tour = tour
            };
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(BookingViewModel vm)
        {
            var tour = await _context.Tours.FindAsync(vm.TourId);
            vm.Tour = tour;

            if (vm.TravelDate < DateTime.Today)
                ModelState.AddModelError("TravelDate", "Travel date cannot be in the past.");

            if (!ModelState.IsValid) return View(vm);

            var booking = new Booking
            {
                UserName = vm.UserName,
                Email = vm.Email,
                Phone = vm.Phone,
                TravelDate = vm.TravelDate,
                NumberOfTravelers = vm.NumberOfTravelers,
                SpecialRequests = vm.SpecialRequests,
                TourId = vm.TourId,
                Status = BookingStatus.Pending
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Confirmation), new { id = booking.Id });
        }

        public async Task<IActionResult> Confirmation(int id)
        {
            var booking = await _context.Bookings
                .Include(b => b.Tour)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (booking == null) return NotFound();
            return View(booking);
        }
    }
}
