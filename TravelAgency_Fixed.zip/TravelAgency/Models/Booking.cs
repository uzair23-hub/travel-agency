using System.ComponentModel.DataAnnotations;

namespace TravelAgency.Models
{
    public class Booking
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string UserName { get; set; } = string.Empty;

        [Required, EmailAddress, MaxLength(200)]
        public string Email { get; set; } = string.Empty;

        [Required, Phone, MaxLength(20)]
        public string Phone { get; set; } = string.Empty;

        [Required]
        public DateTime TravelDate { get; set; }

        [Range(1, 20)]
        public int NumberOfTravelers { get; set; } = 1;

        public string? SpecialRequests { get; set; }

        public BookingStatus Status { get; set; } = BookingStatus.Pending;

        public DateTime BookedAt { get; set; } = DateTime.UtcNow;

        public int TourId { get; set; }
        public Tour? Tour { get; set; }

        public string? UserId { get; set; }
    }

    public enum BookingStatus
    {
        Pending,
        Confirmed,
        Cancelled,
        Completed
    }
}
